#include "derived.h"

derived::derived(/* args */)
{
}

derived::~derived()
{
}