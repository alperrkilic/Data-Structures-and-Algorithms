#include "poly.h"

base::base(/* args */)
{
}

base::~base()
{
}